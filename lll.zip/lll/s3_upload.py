###############################################################################
# s3_upload.py - Funções para upload de arquivos para Amazon S3 com notificações
###############################################################################
import boto3
from botocore.exceptions import ClientError
import os
import json
import logging
from datetime import datetime

# Configurar logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s"
)
logger = logging.getLogger("S3Upload")

# Configurações da AWS S3
S3_CONFIG = {
    "aws_access_key_id": "AKIA6O7CAHHUABTFCDAA",
    "aws_secret_access_key": "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",
    "region_name": "us-east-1", 
    "bucket_name": "compras-ia-np",
    
    # Configurações de notificação
    "notify_uploads": True,             # Ativar notificações de upload
    "notification_email": "",           # Email para receber notificações
    "webhook_url": "",                  # URL para webhooks (Slack, Discord, etc.)
    "sns_topic_arn": "",                # ARN do tópico SNS (configurado automaticamente)
    "monitor_uploads": False,           # Ativar monitoramento de novos uploads
    "monitor_interval": 300             # Intervalo de monitoramento em segundos
}

def upload_file_to_s3(file_path, s3_key=None, notify=True):
    """
    Faz upload de um arquivo para o bucket S3 configurado.
    
    Args:
        file_path (str): Caminho local do arquivo a ser enviado
        s3_key (str, optional): Caminho/nome do arquivo no S3. Se None, usa o nome do arquivo
        notify (bool): Se True, emite notificação após o upload
    
    Returns:
        tuple: (sucesso, mensagem)
    """
    # Se s3_key não foi especificado, usar o nome do arquivo
    if s3_key is None:
        s3_key = os.path.basename(file_path)
    
    # Verificar se o arquivo existe
    if not os.path.exists(file_path):
        logger.error(f"Arquivo não encontrado: {file_path}")
        return False, f"Arquivo não encontrado: {file_path}"
    
    try:
        # Verificar se as credenciais foram configuradas
        if not S3_CONFIG["aws_access_key_id"] or not S3_CONFIG["aws_secret_access_key"]:
            logger.error("Credenciais AWS não configuradas")
            return False, "Credenciais AWS não configuradas. Configure em 'Configurar Amazon S3'."
        
        # Obter tamanho do arquivo para logging
        file_size = os.path.getsize(file_path)
        
        # Inicializar cliente S3
        s3_client = boto3.client(
            's3',
            aws_access_key_id=S3_CONFIG["aws_access_key_id"],
            aws_secret_access_key=S3_CONFIG["aws_secret_access_key"],
            region_name=S3_CONFIG["region_name"]
        )
        
        logger.info(f"Iniciando upload do arquivo: {file_path} para {s3_key}")
        
        # Registrar tempo inicial para medir desempenho
        start_time = datetime.now()
        
        # Fazer upload do arquivo
        s3_client.upload_file(
            file_path, 
            S3_CONFIG["bucket_name"], 
            s3_key,
            Callback=ProgressPercentage(file_path)  # Adicionar monitoramento de progresso
        )
        
        # Calcular tempo de upload
        upload_time = (datetime.now() - start_time).total_seconds()
        
        # Construir URL para o arquivo
        s3_url = f"s3://{S3_CONFIG['bucket_name']}/{s3_key}"
        
        logger.info(f"Upload concluído com sucesso: {s3_url} (Tempo: {upload_time:.2f}s)")
        
        # Enviar notificação de upload bem-sucedido (se ativado)
        if notify and S3_CONFIG.get("notify_uploads", True):
            send_upload_notification(s3_key, S3_CONFIG["bucket_name"], file_size, upload_time)
            log_upload_event(True, file_path, s3_key, f"Upload concluído em {upload_time:.2f}s")
        
        return True, f"Arquivo enviado com sucesso para {s3_url}"
        
    except ClientError as e:
        error_message = f"Erro AWS ao enviar arquivo para S3: {str(e)}"
        logger.error(error_message)
        
        # Registrar falha no log
        if notify:
            log_upload_event(False, file_path, s3_key, error_message)
        
        return False, error_message
    except Exception as e:
        error_message = f"Erro inesperado ao enviar arquivo para S3: {str(e)}"
        logger.error(error_message, exc_info=True)
        
        # Registrar falha no log
        if notify:
            log_upload_event(False, file_path, s3_key, error_message)
        
        return False, error_message

def check_file_exists_in_s3(s3_key):
    """
    Verifica se um arquivo existe no bucket S3.
    
    Args:
        s3_key (str): Caminho/nome do arquivo no S3
    
    Returns:
        bool: True se o arquivo existe, False caso contrário
    """
    try:
        # Verificar se as credenciais foram configuradas
        if not S3_CONFIG["aws_access_key_id"] or not S3_CONFIG["aws_secret_access_key"]:
            logger.error("Credenciais AWS não configuradas")
            return False
            
        # Inicializar cliente S3
        s3_client = boto3.client(
            's3',
            aws_access_key_id=S3_CONFIG["aws_access_key_id"],
            aws_secret_access_key=S3_CONFIG["aws_secret_access_key"],
            region_name=S3_CONFIG["region_name"]
        )
        
        # Verificar se o arquivo existe
        s3_client.head_object(
            Bucket=S3_CONFIG["bucket_name"],
            Key=s3_key
        )
        
        logger.info(f"Arquivo encontrado no S3: {s3_key}")
        return True
        
    except ClientError as e:
        if e.response['Error']['Code'] == '404':
            logger.info(f"Arquivo não encontrado no S3: {s3_key}")
            return False
        else:
            logger.error(f"Erro ao verificar arquivo no S3: {str(e)}")
            return False
    except Exception as e:
        logger.error(f"Erro inesperado ao verificar arquivo no S3: {str(e)}")
        return False

def list_bucket_files(prefix=None, limit=100):
    """
    Lista arquivos no bucket S3.
    
    Args:
        prefix (str, optional): Prefixo para filtrar arquivos
        limit (int, optional): Limite de arquivos a retornar
    
    Returns:
        tuple: (sucesso, lista_de_arquivos ou mensagem_de_erro)
    """
    try:
        # Verificar se as credenciais foram configuradas
        if not S3_CONFIG["aws_access_key_id"] or not S3_CONFIG["aws_secret_access_key"]:
            logger.error("Credenciais AWS não configuradas")
            return False, "Credenciais AWS não configuradas. Configure em 'Configurar Amazon S3'."
            
        # Inicializar cliente S3
        s3_client = boto3.client(
            's3',
            aws_access_key_id=S3_CONFIG["aws_access_key_id"],
            aws_secret_access_key=S3_CONFIG["aws_secret_access_key"],
            region_name=S3_CONFIG["region_name"]
        )
        
        # Preparar parâmetros
        params = {
            'Bucket': S3_CONFIG["bucket_name"],
            'MaxKeys': limit
        }
        
        if prefix:
            params['Prefix'] = prefix
        
        # Listar objetos
        response = s3_client.list_objects_v2(**params)
        
        # Extrair informações dos arquivos
        files = []
        if 'Contents' in response:
            for obj in response['Contents']:
                files.append({
                    'key': obj['Key'],
                    'size': obj['Size'],
                    'last_modified': obj['LastModified'],
                    'url': f"s3://{S3_CONFIG['bucket_name']}/{obj['Key']}"
                })
        
        logger.info(f"Listagem de arquivos concluída. {len(files)} arquivos encontrados.")
        return True, files
        
    except ClientError as e:
        error_message = f"Erro AWS ao listar arquivos no S3: {str(e)}"
        logger.error(error_message)
        return False, error_message
    except Exception as e:
        error_message = f"Erro inesperado ao listar arquivos no S3: {str(e)}"
        logger.error(error_message, exc_info=True)
        return False, error_message

# Classe para exibir progresso do upload
class ProgressPercentage:
    """Classe para monitorar e exibir o progresso do upload"""
    
    def __init__(self, filename):
        self._filename = filename
        self._size = float(os.path.getsize(filename))
        self._seen_so_far = 0
        self._last_percentage = 0
        
    def __call__(self, bytes_amount):
        self._seen_so_far += bytes_amount
        percentage = (self._seen_so_far / self._size) * 100
        
        # Para evitar logging excessivo, só log a cada 10%
        if int(percentage / 10) > int(self._last_percentage / 10):
            logger.info(f"{os.path.basename(self._filename)}: {percentage:.1f}% concluído")
            self._last_percentage = percentage

def format_size(size_bytes):
    """Formata um tamanho em bytes para uma string legível"""
    for unit in ['B', 'KB', 'MB', 'GB', 'TB']:
        if size_bytes < 1024.0:
            return f"{size_bytes:.2f} {unit}"
        size_bytes /= 1024.0
    return f"{size_bytes:.2f} PB"

def log_upload_event(success, file_path, s3_key, message):
    """
    Registra um evento de upload no log local
    
    Args:
        success (bool): Se o upload foi bem-sucedido
        file_path (str): Caminho local do arquivo
        s3_key (str): Caminho/nome do arquivo no S3
        message (str): Mensagem ou detalhes adicionais
    """
    try:
        # Criar diretório de logs se não existir
        log_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "logs")
        os.makedirs(log_dir, exist_ok=True)
        
        # Abrir arquivo de log em modo append
        log_file = os.path.join(log_dir, "s3_uploads.log")
        with open(log_file, "a", encoding="utf-8") as f:
            timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            status = "SUCCESS" if success else "FAILURE"
            
            f.write(f"{timestamp} | {status} | {file_path} | {s3_key or 'N/A'} | {message}\n")
        
        return True
    except Exception as e:
        logger.error(f"Erro ao registrar evento de upload: {str(e)}")
        return False

def send_upload_notification(s3_key, bucket, file_size, upload_time):
    """
    Envia notificação sobre o upload concluído
    
    Args:
        s3_key (str): Caminho/nome do arquivo no S3
        bucket (str): Nome do bucket
        file_size (int): Tamanho do arquivo em bytes
        upload_time (float): Tempo de upload em segundos
    """
    try:
        # Método 1: Webhook (Slack, Discord, etc.)
        if S3_CONFIG.get("webhook_url"):
            send_webhook_notification(s3_key, bucket, file_size, upload_time)
        
        # Método 2: Email via SES (se configurado)
        if S3_CONFIG.get("notification_email"):
            send_email_notification(s3_key, bucket, file_size, upload_time)
        
        # Método 3: SNS (se configurado)
        if S3_CONFIG.get("sns_topic_arn"):
            send_sns_notification(s3_key, bucket, file_size, upload_time)
        
        logger.info(f"Notificações enviadas para o upload: {s3_key}")
        return True
    except Exception as e:
        logger.error(f"Erro ao enviar notificações: {str(e)}")
        return False

def send_webhook_notification(s3_key, bucket, file_size, upload_time):
    """
    Envia notificação para webhook configurado (Slack, Discord, etc.)
    
    Args:
        s3_key (str): Caminho/nome do arquivo no S3
        bucket (str): Nome do bucket
        file_size (int): Tamanho do arquivo em bytes
        upload_time (float): Tempo de upload em segundos
    """
    try:
        import requests
        
        webhook_url = S3_CONFIG.get("webhook_url")
        if not webhook_url:
            return False
        
        formatted_size = format_size(file_size)
        
        # Formato específico para Slack
        if "hooks.slack.com" in webhook_url:
            payload = {
                "text": "Upload S3 concluído",
                "attachments": [
                    {
                        "color": "#36a64f",
                        "title": "Upload S3 concluído com sucesso",
                        "fields": [
                            {"title": "Arquivo", "value": s3_key, "short": True},
                            {"title": "Bucket", "value": bucket, "short": True},
                            {"title": "Tamanho", "value": formatted_size, "short": True},
                            {"title": "Tempo", "value": f"{upload_time:.2f}s", "short": True}
                        ],
                        "footer": "Compras IA - Upload S3",
                        "ts": int(datetime.now().timestamp())
                    }
                ]
            }
        # Formato genérico para outros webhooks
        else:
            payload = {
                "title": "Upload S3 concluído",
                "message": f"Arquivo '{s3_key}' enviado para S3 com sucesso",
                "details": {
                    "bucket": bucket,
                    "key": s3_key,
                    "size": formatted_size,
                    "upload_time_seconds": upload_time,
                    "s3_uri": f"s3://{bucket}/{s3_key}"
                },
                "timestamp": datetime.now().isoformat()
            }
        
        # Enviar payload para o webhook
        response = requests.post(
            webhook_url, 
            json=payload,
            headers={"Content-Type": "application/json"}
        )
        
        success = response.status_code == 200
        
        if success:
            logger.info(f"Notificação webhook enviada com sucesso: {webhook_url}")
        else:
            logger.error(f"Erro ao enviar webhook: {response.status_code} - {response.text}")
        
        return success
    except Exception as e:
        logger.error(f"Erro ao enviar notificação webhook: {str(e)}")
        return False

def send_email_notification(s3_key, bucket, file_size, upload_time):
    """
    Envia notificação por email usando Amazon SES
    
    Args:
        s3_key (str): Caminho/nome do arquivo no S3
        bucket (str): Nome do bucket
        file_size (int): Tamanho do arquivo em bytes
        upload_time (float): Tempo de upload em segundos
    """
    try:
        email = S3_CONFIG.get("notification_email")
        if not email:
            return False
        
        # Inicializar cliente SES
        ses_client = boto3.client(
            'ses',
            aws_access_key_id=S3_CONFIG["aws_access_key_id"],
            aws_secret_access_key=S3_CONFIG["aws_secret_access_key"],
            region_name=S3_CONFIG["region_name"]
        )
        
        formatted_size = format_size(file_size)
        
        # Criar corpo do email
        subject = f"Upload S3 Concluído: {os.path.basename(s3_key)}"
        
        body_html = f"""
        <html>
        <head></head>
        <body>
            <h2>Upload S3 Concluído</h2>
            <p>Um arquivo foi enviado com sucesso para o S3:</p>
            <ul>
                <li><strong>Arquivo:</strong> {s3_key}</li>
                <li><strong>Bucket:</strong> {bucket}</li>
                <li><strong>Tamanho:</strong> {formatted_size}</li>
                <li><strong>Tempo:</strong> {upload_time:.2f}s</li>
                <li><strong>S3 URI:</strong> s3://{bucket}/{s3_key}</li>
            </ul>
            <p>Este email é uma notificação automática do sistema Compras IA.</p>
        </body>
        </html>
        """
        
        # Enviar email
        response = ses_client.send_email(
            Source=email,  # O remetente deve ser verificado no SES
            Destination={'ToAddresses': [email]},
            Message={
                'Subject': {'Data': subject},
                'Body': {'Html': {'Data': body_html}}
            }
        )
        
        success = 'MessageId' in response
        
        if success:
            logger.info(f"Email de notificação enviado com sucesso para {email}")
        else:
            logger.error(f"Erro ao enviar email: {response}")
        
        return success
    except Exception as e:
        logger.error(f"Erro ao enviar notificação por email: {str(e)}")
        return False

def send_sns_notification(s3_key, bucket, file_size, upload_time):
    """
    Envia notificação via Amazon SNS
    
    Args:
        s3_key (str): Caminho/nome do arquivo no S3
        bucket (str): Nome do bucket
        file_size (int): Tamanho do arquivo em bytes
        upload_time (float): Tempo de upload em segundos
    """
    try:
        topic_arn = S3_CONFIG.get("sns_topic_arn")
        if not topic_arn:
            return False
        
        # Inicializar cliente SNS
        sns_client = boto3.client(
            'sns',
            aws_access_key_id=S3_CONFIG["aws_access_key_id"],
            aws_secret_access_key=S3_CONFIG["aws_secret_access_key"],
            region_name=S3_CONFIG["region_name"]
        )
        
        formatted_size = format_size(file_size)
        
        # Mensagem em diferentes formatos para diferentes canais de notificação
        message = {
            # Formato padrão (usado se não houver protocolo específico)
            "default": f"Upload S3 concluído: {s3_key} ({formatted_size}) em {upload_time:.2f}s",
            
            # Formato para email
            "email": f"""Upload S3 Concluído

Arquivo: {s3_key}
Bucket: {bucket}
Tamanho: {formatted_size}
Tempo: {upload_time:.2f}s
S3 URI: s3://{bucket}/{s3_key}

Este email é uma notificação automática do sistema Compras IA.
""",
            
            # Formato para SMS (mais curto)
            "sms": f"Compras IA: Upload concluído - {os.path.basename(s3_key)} ({formatted_size})"
        }
        
        # Enviar para o tópico SNS
        response = sns_client.publish(
            TopicArn=topic_arn,
            Message=json.dumps(message),
            MessageStructure='json',
            Subject=f"Upload S3 Concluído: {os.path.basename(s3_key)}"
        )
        
        success = 'MessageId' in response
        
        if success:
            logger.info(f"Notificação SNS enviada com sucesso para {topic_arn}")
        else:
            logger.error(f"Erro ao enviar notificação SNS: {response}")
        
        return success
    except Exception as e:
        logger.error(f"Erro ao enviar notificação SNS: {str(e)}")
        return False

def setup_s3_event_notifications(bucket_name=None, topic_arn=None, lambda_arn=None, email=None):
    """
    Configura notificações de eventos do S3 quando novos objetos são criados
    
    Args:
        bucket_name (str, optional): Nome do bucket S3
        topic_arn (str, optional): ARN do tópico SNS para notificações
        lambda_arn (str, optional): ARN da função Lambda
        email (str, optional): Email para receber notificações (via SNS)
    
    Returns:
        bool: True se configurado com sucesso, False caso contrário
    """
    try:
        if bucket_name is None:
            bucket_name = S3_CONFIG.get("bucket_name")
        
        # Inicializar cliente S3
        s3_client = boto3.client(
            's3',
            aws_access_key_id=S3_CONFIG["aws_access_key_id"],
            aws_secret_access_key=S3_CONFIG["aws_secret_access_key"],
            region_name=S3_CONFIG["region_name"]
        )
        
        # Criar tópico SNS se email for fornecido mas não houver topic_arn
        if email and not topic_arn:
            sns_client = boto3.client(
                'sns',
                aws_access_key_id=S3_CONFIG["aws_access_key_id"],
                aws_secret_access_key=S3_CONFIG["aws_secret_access_key"],
                region_name=S3_CONFIG["region_name"]
            )
            
            # Criar nome para o tópico baseado no bucket
            topic_name = f"S3Uploads-{bucket_name.replace('-', '')}-Notifications"
            
            # Criar tópico
            topic_response = sns_client.create_topic(Name=topic_name)
            topic_arn = topic_response['TopicArn']
            
            # Inscrever email no tópico
            sns_client.subscribe(
                TopicArn=topic_arn,
                Protocol='email',
                Endpoint=email
            )
            
            logger.info(f"Tópico SNS criado e email {email} inscrito: {topic_arn}")
            
            # Salvar ARN do tópico na configuração
            S3_CONFIG["sns_topic_arn"] = topic_arn
            
            # Esperando confirmação da inscrição pelo usuário
            logger.info(f"Um email de confirmação foi enviado para {email}. " +
                       "Por favor, confirme a inscrição para receber notificações.")
        
        # Configurar notificação
        notification_config = {
            'TopicConfigurations': [] if not topic_arn else [{
                'TopicArn': topic_arn,
                'Events': ['s3:ObjectCreated:*'],
                'Filter': {'Key': {'FilterRules': [{'Name': 'prefix', 'Value': 'Contratos/'}]}}
            }],
            'LambdaFunctionConfigurations': [] if not lambda_arn else [{
                'LambdaFunctionArn': lambda_arn,
                'Events': ['s3:ObjectCreated:*'],
                'Filter': {'Key': {'FilterRules': [{'Name': 'prefix', 'Value': 'Contratos/'}]}}
            }]
        }
        
        # Aplicar configuração
        s3_client.put_bucket_notification_configuration(
            Bucket=bucket_name,
            NotificationConfiguration=notification_config
        )
        
        logger.info(f"Configuração de notificação S3 concluída para o bucket: {bucket_name}")
        return True
    
    except Exception as e:
        logger.error(f"Erro ao configurar notificações S3: {str(e)}")
        return False

# Verificar configuração de email no SES
def verify_ses_email(email):
    """
    Verifica um endereço de email no Amazon SES para envio de emails
    
    Args:
        email (str): Endereço de email a ser verificado
    
    Returns:
        bool: True se solicitação enviada com sucesso
    """
    try:
        # Inicializar cliente SES
        ses_client = boto3.client(
            'ses',
            aws_access_key_id=S3_CONFIG["aws_access_key_id"],
            aws_secret_access_key=S3_CONFIG["aws_secret_access_key"],
            region_name=S3_CONFIG["region_name"]
        )
        
        # Verificar se o email já está verificado
        response = ses_client.get_identity_verification_attributes(
            Identities=[email]
        )
        
        # Verificar se o email já existe e está verificado
        attributes = response.get('VerificationAttributes', {})
        if email in attributes and attributes[email]['VerificationStatus'] == 'Success':
            logger.info(f"Email {email} já está verificado no SES")
            return True
        
        # Enviar solicitação de verificação
        ses_client.verify_email_identity(
            EmailAddress=email
        )
        
        logger.info(f"Solicitação de verificação enviada para {email}. " +
                   "Por favor, verifique sua caixa de entrada e confirme o email.")
        return True
    
    except Exception as e:
        logger.error(f"Erro ao verificar email no SES: {str(e)}")
        return False

# Função para testar a configuração das notificações
def test_notifications(test_message=None):
    """
    Testa os canais de notificação configurados
    
    Args:
        test_message (str, optional): Mensagem de teste personalizada
    
    Returns:
        dict: Resultados dos testes para cada canal
    """
    results = {
        "webhook": False,
        "email": False,
        "sns": False
    }
    
    try:
        if not test_message:
            test_message = f"Teste de notificação - {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"
        
        # Testar webhook
        if S3_CONFIG.get("webhook_url"):
            try:
                import requests
                
                webhook_url = S3_CONFIG.get("webhook_url")
                
                # Formato para Slack
                if "hooks.slack.com" in webhook_url:
                    payload = {
                        "text": "Teste de notificação S3",
                        "attachments": [
                            {
                                "color": "#36a64f",
                                "title": "Teste de sistema de notificação",
                                "text": test_message,
                                "footer": "Compras IA - Sistema de Notificação",
                                "ts": int(datetime.now().timestamp())
                            }
                        ]
                    }
                # Formato genérico
                else:
                    payload = {
                        "title": "Teste de Notificação",
                        "message": test_message,
                        "timestamp": datetime.now().isoformat()
                    }
                
                response = requests.post(webhook_url, json=payload)
                results["webhook"] = response.status_code == 200
                
                if results["webhook"]:
                    logger.info(f"Teste de webhook enviado com sucesso: {webhook_url}")
                else:
                    logger.error(f"Erro no teste de webhook: {response.status_code} - {response.text}")
            
            except Exception as e:
                logger.error(f"Erro ao testar webhook: {str(e)}")
        
        # Testar email
        if S3_CONFIG.get("notification_email"):
            try:
                email = S3_CONFIG.get("notification_email")
                
                # Verificar se o email está verificado no SES
                ses_client = boto3.client(
                    'ses',
                    aws_access_key_id=S3_CONFIG["aws_access_key_id"],
                    aws_secret_access_key=S3_CONFIG["aws_secret_access_key"],
                    region_name=S3_CONFIG["region_name"]
                )
                
                # Tentar enviar email de teste
                response = ses_client.send_email(
                    Source=email,  # O remetente deve ser verificado no SES
                    Destination={'ToAddresses': [email]},
                    Message={
                        'Subject': {'Data': 'Teste de Notificação S3'},
                        'Body': {
                            'Text': {'Data': test_message},
                            'Html': {
                                'Data': f"""
                                <html>
                                <head></head>
                                <body>
                                    <h2>Teste de Sistema de Notificação</h2>
                                    <p>{test_message}</p>
                                    <p>Este é um teste do sistema de notificação do Compras IA.</p>
                                </body>
                                </html>
                                """
                            }
                        }
                    }
                )
                
                results["email"] = 'MessageId' in response
                
                if results["email"]:
                    logger.info(f"Teste de email enviado com sucesso para {email}")
                else:
                    logger.error(f"Erro no teste de email: {response}")
            
            except Exception as e:
                logger.error(f"Erro ao testar email: {str(e)}")
                
                # Verificar se é erro de email não verificado
                if "Email address is not verified" in str(e):
                    logger.info(f"Email {S3_CONFIG.get('notification_email')} não está verificado. Enviando solicitação de verificação...")
                    verify_ses_email(S3_CONFIG.get("notification_email"))
        
        # Testar SNS
        if S3_CONFIG.get("sns_topic_arn"):
            try:
                topic_arn = S3_CONFIG.get("sns_topic_arn")
                
                sns_client = boto3.client(
                    'sns',
                    aws_access_key_id=S3_CONFIG["aws_access_key_id"],
                    aws_secret_access_key=S3_CONFIG["aws_secret_access_key"],
                    region_name=S3_CONFIG["region_name"]
                )
                
                message = {
                    "default": test_message,
                    "email": f"Teste de Notificação SNS\n\n{test_message}\n\nEste é um teste do sistema de notificação do Compras IA.",
                    "sms": f"Compras IA: {test_message}"
                }
                
                response = sns_client.publish(
                    TopicArn=topic_arn,
                    Message=json.dumps(message),
                    MessageStructure='json',
                    Subject="Teste de Notificação S3"
                )
                
                results["sns"] = 'MessageId' in response
                
                if results["sns"]:
                    logger.info(f"Teste de SNS enviado com sucesso para {topic_arn}")
                else:
                    logger.error(f"Erro no teste de SNS: {response}")
            
            except Exception as e:
                logger.error(f"Erro ao testar SNS: {str(e)}")
        
        return results
    
    except Exception as e:
        logger.error(f"Erro ao testar notificações: {str(e)}")
        return results

# Exemplo de uso direto do módulo
if __name__ == "__main__":
    import sys
    
    # Se for chamado com --setup-notifications
    if len(sys.argv) > 1 and sys.argv[1] == "--setup-notifications":
        email = input("Email para notificações (opcional): ")
        if email:
            print(f"Configurando notificações para o email: {email}")
            S3_CONFIG["notification_email"] = email
            
            # Verificar email no SES
            if verify_ses_email(email):
                print(f"✅ Solicitação de verificação enviada para {email}. Verifique sua caixa de entrada.")
            
            # Configurar notificações S3
            if setup_s3_event_notifications(email=email):
                print("✅ Notificações S3 configuradas com sucesso!")
            else:
                print("❌ Erro ao configurar notificações S3.")
    
    # Se for chamado com --test-notifications
    elif len(sys.argv) > 1 and sys.argv[1] == "--test-notifications":
        print("Testando notificações configuradas...")
        results = test_notifications("Este é um teste do sistema de notificação")
        
        print("\nResultado dos testes:")
        for channel, result in results.items():
            status = "✅ Sucesso" if result else "❌ Falha ou não configurado"
            print(f"{channel}: {status}")
    
    # Uso padrão - upload de arquivo
    elif len(sys.argv) > 1 and os.path.exists(sys.argv[1]):
        file_path = sys.argv[1]
        s3_key = sys.argv[2] if len(sys.argv) > 2 else None
        
        print(f"Enviando arquivo {file_path} para S3...")
        success, message = upload_file_to_s3(file_path, s3_key)
        
        if success:
            print(f"✅ {message}")
        else:
            print(f"❌ {message}")
    
    # Ajuda
    else:
        print("Uso:")
        print("  python s3_upload.py arquivo.txt [caminho/s3.txt]")
        print("  python s3_upload.py --setup-notifications")
        print("  python s3_upload.py --test-notifications")