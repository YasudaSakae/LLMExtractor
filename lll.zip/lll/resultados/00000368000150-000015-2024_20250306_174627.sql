-- Inserindo Orgao Contratante
INSERT INTO precos.orgao_contratante (razao_social, sigla, cnpj)
VALUES ('CASA MILITAR DO GABINETE DO GOVERNADOR', 'Parcial', '00.000.368/0001-50')
ON CONFLICT (cnpj) DO NOTHING; 

-- Inserindo Empresa Contratada
INSERT INTO precos.empresa_contratada (razao_social, cnpj)
VALUES ('Nexti Tecnologia da Informação LTDA', '26.912.759/0001-34')
ON CONFLICT (cnpj) DO NOTHING;

-- Inserir contrato (se não existir) e obter ID
WITH contrato_upsert AS (
    INSERT INTO precos.contratos (
        numero_contrato,
        tipo_instrumento,
        processo_administrativo,
        data_celebracao,
        fonte_preco,
        referencia_contrato,
        url_pdf_s3,
        status_extracao,
        orgao_contratante_id,
        empresa_contratada_id
    )
    SELECT 
        '007/2024',
        'Contrato',
        '003.00001224/2024-30',
        TO_DATE('22/07/2024', 'DD/MM/YYYY'),
        'Contrato',
        '007/2024',
        's3://compras-ia-np/Contratos/00000368000150-000015-2024.pdf',
        'Sucesso',
        (SELECT id FROM precos.orgao_contratante WHERE cnpj = '00.000.368/0001-50' LIMIT 1),
        (SELECT id FROM precos.empresa_contratada WHERE cnpj = '26.912.759/0001-34' LIMIT 1)
    WHERE 
        NOT EXISTS (
            SELECT 1 
            FROM precos.contratos 
            WHERE numero_contrato = '007/2024'
              AND url_pdf_s3 = 's3://compras-ia-np/Contratos/00000368000150-000015-2024.pdf'
        )
    RETURNING id
)
, contrato_id AS (
    SELECT id FROM contrato_upsert
    UNION ALL
    SELECT id FROM precos.contratos 
    WHERE numero_contrato = '007/2024'
      AND url_pdf_s3 = 's3://compras-ia-np/Contratos/00000368000150-000015-2024.pdf'
      AND NOT EXISTS (SELECT 1 FROM contrato_upsert)
    LIMIT 1
)
-- Inserir itens
INSERT INTO precos.itens (
    contrato_id,
    descricao,
    especificacao,
    unidade_medida,
    quantidade,
    valor_unitario,
    valor_total,
    catmat_catser,
    tipo,
    locais_execucao_entrega
)
SELECT

    id,
    'MONITOR 55"',
    'Parcial',
    'UNIDADE',
    '15',
    'R$ 85.434,00',
    'R$ 1.281.510,00',
    '604256',
    'Material',
    'Parcial'
FROM contrato_id
UNION ALL
SELECT

    id,
    'GERENCIADOR GRAFICO',
    'Parcial',
    'UNIDADE',
    '1',
    'R$ 25.800,00',
    'R$ 25.800,00',
    '465017',
    'Material',
    'Parcial'
FROM contrato_id
UNION ALL
SELECT

    id,
    'CABO DISPLAYPORT 1.2',
    'Parcial',
    'UNIDADE',
    '2',
    'R$ 4.100,00',
    'R$ 8.200,00',
    '415538',
    'Material',
    'Parcial'
FROM contrato_id
UNION ALL
SELECT

    id,
    'ENCODER HDMI',
    'Parcial',
    'UNIDADE',
    '2',
    'R$ 12.700,00',
    'R$ 25.400,00',
    '407087',
    'Material',
    'Parcial'
FROM contrato_id
UNION ALL
SELECT

    id,
    'ADEQUAÇÃO CARENAGEM',
    'Parcial',
    'UNIDADE',
    '1',
    'R$ 61.916,00',
    'R$ 61.916,00',
    '485896',
    'Material',
    'Parcial'
FROM contrato_id
UNION ALL
SELECT

    id,
    'INSTALAÇÃO',
    'Parcial',
    'UNIDADE',
    '1',
    'R$ 129.860,00',
    'R$ 129.860,00',
    '26972',
    'Material',
    'Parcial'
FROM contrato_id
UNION ALL
SELECT

    id,
    'TREINAMENTO',
    'Parcial',
    'UNIDADE',
    '1',
    'R$ 12.350,00',
    'R$ 12.350,00',
    '21172',
    'Material',
    'Parcial'
FROM contrato_id
;